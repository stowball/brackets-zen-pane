# brackets-zen-pane

Reduce the opacity of the non-focused pane to reduce distractions

Compatible with release 44 and above